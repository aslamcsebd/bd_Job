
<?php   

   $area=$_POST['area'];
   // $area=='dhaka'
   
   $jobType=$_POST['jobType'];
   // $jobType=='eee'

   $education=$_POST['education'];
   // $education=='psc')

   $jobTitle=$_POST['jobTitle'];
   $salary=$_POST['salary'];
   $experience=$_POST['experience'];
   $applyDate=$_POST['applyDate'];

  // $conn =mysqli_connect('localhost','root','','tableName'); 

   $conn =mysqli_connect('localhost','root','',$area); 


   $sql= "insert into $jobType values (null, '$jobTitle', '$education', '$salary', '$experience', '$applyDate')";

   $result=mysqli_query($conn,$sql);

   if ($result) {     
      echo "success";
      header("Location: adminHome.php");         
   }
?>