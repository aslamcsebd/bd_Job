<?php   
   $userId=$_POST['userId'];
   $password=$_POST['password'];

   $conn =mysqli_connect('localhost','root','','bdjob');  

   $sql="select * from login where userId='$userId' AND password='$userPassword' ";

   $result=mysqli_query($conn,$sql);

   if ($result) {
         
         if ($userId=='admin' && $password=='admin') {
           header("Location: adminHome.php");
         }
         else{
            header("Location: index.php");
         }
      }
   else {
         header("Location: loginPage.php");
   }
?>