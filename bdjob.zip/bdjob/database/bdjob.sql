-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2018 at 09:02 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bdjob`
--

-- --------------------------------------------------------

--
-- Table structure for table `jobrequest`
--

CREATE TABLE `jobrequest` (
  `id` int(30) NOT NULL,
  `userName` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  `mobile` int(30) NOT NULL,
  `jobId` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobrequest`
--

INSERT INTO `jobrequest` (`id`, `userName`, `address`, `mobile`, `jobId`) VALUES
(1, 'Md Aslam', 'asas', 5858, 'dhaka > cse > Job id: 1'),
(2, 'Md Aslam', 'asas', 5858, 'dhaka > cse > Job id: 1'),
(3, 'xyz', 'hghjgh', 25252, '5252'),
(4, 'jkgujg', 'hfgvhv', 8585, '5858'),
(5, 'xyz', 'hghjgh', 25252, '5252'),
(6, 'jkgujg', 'hfgvhv', 8585, '5858'),
(7, 'sfs', 'fssf', 0, 'ctg > other > Job id: 1'),
(8, 'hgfghf', 'hfhfh', 0, 'fhfhf');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(30) NOT NULL,
  `userId` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `userId`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'user', 'user'),
(3, 'user2', 'user2'),
(4, 'user3', 'user3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jobrequest`
--
ALTER TABLE `jobrequest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jobrequest`
--
ALTER TABLE `jobrequest`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
