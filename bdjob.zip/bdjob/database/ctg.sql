-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2018 at 09:03 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ctg`
--

-- --------------------------------------------------------

--
-- Table structure for table `cse`
--

CREATE TABLE `cse` (
  `id` int(30) NOT NULL,
  `jobTitle` varchar(255) NOT NULL,
  `education` varchar(30) NOT NULL,
  `salary` varchar(30) NOT NULL,
  `experience` varchar(30) NOT NULL,
  `applyDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cse`
--

INSERT INTO `cse` (`id`, `jobTitle`, `education`, `salary`, `experience`, `applyDate`) VALUES
(1, 'Engineering job', 'psc', '45000', '4 years', '2018-12-07'),
(2, 'Engineering job', 'psc', '45000', '4 years', '2018-12-07');

-- --------------------------------------------------------

--
-- Table structure for table `eee`
--

CREATE TABLE `eee` (
  `id` int(30) NOT NULL,
  `jobTitle` varchar(255) NOT NULL,
  `education` varchar(30) NOT NULL,
  `salary` varchar(30) NOT NULL,
  `experience` varchar(30) NOT NULL,
  `applyDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eee`
--

INSERT INTO `eee` (`id`, `jobTitle`, `education`, `salary`, `experience`, `applyDate`) VALUES
(1, 'Engineering job', 'psc', '45000', '4 years', '2018-12-07');

-- --------------------------------------------------------

--
-- Table structure for table `other`
--

CREATE TABLE `other` (
  `id` int(30) NOT NULL,
  `jobTitle` varchar(255) NOT NULL,
  `education` varchar(30) NOT NULL,
  `salary` varchar(30) NOT NULL,
  `experience` varchar(30) NOT NULL,
  `applyDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `other`
--

INSERT INTO `other` (`id`, `jobTitle`, `education`, `salary`, `experience`, `applyDate`) VALUES
(1, 'Engineering job', 'psc', '45000', '4 years', '2018-12-07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cse`
--
ALTER TABLE `cse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eee`
--
ALTER TABLE `eee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `other`
--
ALTER TABLE `other`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cse`
--
ALTER TABLE `cse`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `eee`
--
ALTER TABLE `eee`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `other`
--
ALTER TABLE `other`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
