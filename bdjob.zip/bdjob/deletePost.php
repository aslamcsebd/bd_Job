
<?php   

	if(isset($_POST['submit'])){

	  	$area=$_POST['area'];  
   	$jobType=$_POST['jobType'];

	   $conn =mysqli_connect('localhost','root','',$area); 
	   $sql="select*from $jobType";
	   $result=mysqli_query($conn,$sql);
	}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="ISO-8859-1">
		<title>User Home</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/style.css">
	</head>
	<body>

<!-------------- navbar  -------------->

		<nav class="navbar navbar-default">
	    	<div class="container">
	        	<div class="navbar-header">          
	            <a class="navbar-brand" href="#">Bd Job</a>
	        	</div>

	        	<div class="collapse navbar-collapse">
	            <ul class="nav navbar-nav navbar-right">
	               <li class="active"><a href="#">Home</a></li>
	               <li><a href="#">Admin</a></li>
	               <li><a href="#">User</a></li>
	               <li><a href="#">Contact</a></li>
	           	</ul>             
	        	</div>
	    	</div>
		</nav>

		<div id="index" class="text-center">
			<h1>Selete for delete post</h1>
			<div class="row">	
				<div class="col-sm-offset-4 col-sm-4" >					
					<form action="deletePost.php" method="POST" style="border:3px solid blue;">				
						<table class="table" border="5px solid blue"  >
		     				<tr>   
		                  <th class="text-right"><label>Area</label></th>
		                     <td>
	                     		<select name='area' required>
						         		<option value="">Select area</option>
						         		<option value="dhaka">Dhaka</option>
						         		<option value="ctg">Chittagon</option>
						      		</select>
		                     </td>     
		               </tr>
		               <tr>   
		                  <th class="text-right"><label>Job Title</label></th>
		                     <td>
		                     	<select name='jobType' required>
								         <option value="">Select type</option>
								         <option value="cse">CSE</option>
								         <option value="eee">EEE</option>
								         <option value="other">Other</option>
								      </select>
		                     </td>     
		               </tr>
		            </table> 					
					<button type="submit" class="btn btn-success" name="submit">Action</button>  
				</form>				
			</div>
		</div>
		<br><br>	

		<?php if(isset($_POST['submit'])){ ?>						
			<h1>Search Result</h1>
			<div class="row">
				<div class="col-sm-offset-4 col-sm-4">											
					<table class="table" border="5px solid blue">
						<thead align="center" style="background-color: #ddd; font-size: 20px;">
							<th>No</th>
							<th>Area</th>
							<th>Type</th>
							<th>Job</th>
							<th>Action</th>
						</thead>
						
					<?php while($row = mysqli_fetch_assoc($result)) { ?>
						<tbody>
							<tr>
								<td><label> <?= $row['id']; ?></label></td>
								<td><label> <?= $area; ?></label></td>
								<td><label> <?= $jobType ; ?></label></td>
								<td><label> <?= $row['jobTitle']; ?></label></td>
								<td><button type="submit" class="btn btn-danger">Delete</button></td>
							</tr>
						</tbody>
					<?php } ?> 
     				</table>  
     			</div>
     		</div>
     	<?php } ?> 

     </div>

    

		<div id="footer">
			<h2 class="text-center">Copyright @ Bd Job</h2>		
		</div>

	</body>
</html>