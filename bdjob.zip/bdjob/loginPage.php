<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="ISO-8859-1">
		<title>Bd Job</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/style.css">
	</head>
	<body>

<!-------------- navbar  -------------->

		<nav class="navbar navbar-default">
	    	<div class="container">
	        	<div class="navbar-header">          
	            <a class="navbar-brand" href="#">Bd Job</a>
	        	</div>

	        	<div class="collapse navbar-collapse">
	            <ul class="nav navbar-nav navbar-right">
	               <li class="active"><a href="#">Home</a></li>
	               <li><a href="loginPage.php">Admin</a></li>
	               <li><a href="loginPage.php">User</a></li>
	               <li><a href="#">Contact</a></li>
	           	</ul>             
	        	</div>
	    	</div>
		</nav>	

		<div id="index" class="text-center">
			<h1>User/Admin Login page</h1>
			<div class="row" style="padding-top: 150px;" >
				
				<form action="confirmLogin.php" method="POST" class="col-sm-offset-4 col-sm-4" style="border:3px solid blue;">	
					
					<table class="table" border="5px solid blue">
		            <tr>
		               <th  class="text-right"><label>User Id</label></th>
		               <td>
		                  <input type="text" name="userId" placeholder="User Id" required>
		               </td>                 
		            </tr>
		            <tr>
		               <th  class="text-right"><label>Password</label></th>
		               <td>
		               	<input type="password" name="password" placeholder="Password" required>
		               </td>                 
		            </tr>
		         </table>
		            <button type="submit" class="btn btn-filled btn-success">Sign in</button>
		      </form>
		   </div>

		</div>

		<div id="footer">
			<h2 class="text-center">Copyright @ Bd Job</h2>		
		</div>
	</body>
</html>